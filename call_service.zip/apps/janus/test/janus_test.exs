defmodule JanusTest do
  use ExUnit.Case

  test "greets the world" do
    assert true
  end
end
