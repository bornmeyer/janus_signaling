defmodule Janus.Participant do
  defstruct id: nil, publishing_plugin: nil, subscribing_plugin: nil
end
