defmodule General do
  @moduledoc """
  Documentation for General.
  """

  @doc """
  Hello world.

  ## Examples

      iex> General.hello()
      :world

  """
  def hello do
    :world
  end
end
