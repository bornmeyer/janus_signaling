import Config
config :janus, dispatcher: Janus.Dispatcher
config :janus, room_manager: Janus.RoomManager
